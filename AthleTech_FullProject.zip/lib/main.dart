import 'package:flutter/material.dart';

void main() {
  runApp(AthleTechApp());
}

class AthleTechApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AthleTech',
      theme: ThemeData(
        primaryColor: Color(0xFF4CAF50),
        scaffoldBackgroundColor: Color(0xFFE0E0E0),
        colorScheme: ColorScheme.fromSwatch().copyWith(
          secondary: Color(0xFF2196F3),
        ),
        fontFamily: 'Sans-serif',
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  final List<Map<String, String>> sportsInfo = [
    {"title": "Cricket", "desc": "Ask about matches, players, and history."},
    {"title": "Football", "desc": "Details about clubs, players, rules."},
    {"title": "Tennis", "desc": "Grand Slams, players, scores."}
  ];

  final List<Map<String, String>> virtualGames = [
    {"name": "Virtual Cricket", "desc": "Coming soon"},
    {"name": "Virtual Football", "desc": "Coming soon"}
  ];

  final List<Map<String, String>> stories = [
    {"title": "Rising from streets", "desc": "From gully cricket to Ranji trophy"},
    {"title": "Underdog", "desc": "Player who made it with no coach or gear"}
  ];

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text("AthleTech"),
          bottom: TabBar(tabs: [
            Tab(text: "Sports AI"),
            Tab(text: "Virtual Sports"),
            Tab(text: "Stories"),
          ]),
        ),
        body: TabBarView(
          children: [
            ListView.builder(
              itemCount: sportsInfo.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(sportsInfo[index]["title"]!),
                  subtitle: Text(sportsInfo[index]["desc"]!),
                );
              },
            ),
            ListView.builder(
              itemCount: virtualGames.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(virtualGames[index]["name"]!),
                  subtitle: Text(virtualGames[index]["desc"]!),
                );
              },
            ),
            ListView.builder(
              itemCount: stories.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(stories[index]["title"]!),
                  subtitle: Text(stories[index]["desc"]!),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
